﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Medley_TicketIssue
{
    public partial class frmOptions : Form
    {
        public frmOptions()
        {
            InitializeComponent();
        }

        private void frmOptions_Load(object sender, EventArgs e)
        {
        }
        private void btnOk_Click(object sender, EventArgs e)
        {

            //Need to do data checks
            //if IsPresent && IsInt && IsPresent && IsDatetime
            if (IsPresent(txtfirstNum, "First Ticket Number") && IsInt(txtfirstNum, "First Ticket Number")
                && IsPresent(txtGuestperwindow, "Guest Per Window") && IsInt(txtGuestperwindow, "Guest Per Window")
                //Check txtMinutes, txtStart, txtEnd
                )
                this.DialogResult = DialogResult.OK;
            //else
        }
        //Write IsPresent method
        public bool IsPresent(TextBox textbox, string name)
        {
            if (textbox.Text == "")
            {
                MessageBox.Show(name + " is a required field.", "Error Entry");
                textbox.Focus();
                return false;
            }
            return true;
        }
        //Write IsInt method (modified from IsDouble)
        public bool IsInt(TextBox textbox, string name)
        {
            return true;
        }
        //Write IsDateTime method (modified from IsDouble)
        public bool IsDateTime(TextBox textbox, string name)
        {
            return true;
        }
    }
}

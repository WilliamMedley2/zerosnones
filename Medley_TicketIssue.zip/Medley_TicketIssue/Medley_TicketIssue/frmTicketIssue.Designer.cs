﻿namespace Medley_TicketIssue
{
    partial class frmTicketIssue
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTicketAvailability = new System.Windows.Forms.Label();
            this.lblTotalTicketsIssued = new System.Windows.Forms.Label();
            this.lblNextAvailibleEntry = new System.Windows.Forms.Label();
            this.txtTotalTicketsIssued = new System.Windows.Forms.TextBox();
            this.txtNextAvailibleEntry = new System.Windows.Forms.TextBox();
            this.btnIssueTicket = new System.Windows.Forms.Button();
            this.btnOptions = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.lstTickets = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // lblTicketAvailability
            // 
            this.lblTicketAvailability.AutoSize = true;
            this.lblTicketAvailability.Location = new System.Drawing.Point(15, 9);
            this.lblTicketAvailability.Name = "lblTicketAvailability";
            this.lblTicketAvailability.Size = new System.Drawing.Size(89, 13);
            this.lblTicketAvailability.TabIndex = 0;
            this.lblTicketAvailability.Text = "Ticket Availability";
            // 
            // lblTotalTicketsIssued
            // 
            this.lblTotalTicketsIssued.AutoSize = true;
            this.lblTotalTicketsIssued.Location = new System.Drawing.Point(12, 48);
            this.lblTotalTicketsIssued.Name = "lblTotalTicketsIssued";
            this.lblTotalTicketsIssued.Size = new System.Drawing.Size(103, 13);
            this.lblTotalTicketsIssued.TabIndex = 1;
            this.lblTotalTicketsIssued.Text = "Total Tickets Issued";
            // 
            // lblNextAvailibleEntry
            // 
            this.lblNextAvailibleEntry.AutoSize = true;
            this.lblNextAvailibleEntry.Location = new System.Drawing.Point(15, 77);
            this.lblNextAvailibleEntry.Name = "lblNextAvailibleEntry";
            this.lblNextAvailibleEntry.Size = new System.Drawing.Size(98, 13);
            this.lblNextAvailibleEntry.TabIndex = 2;
            this.lblNextAvailibleEntry.Text = "Next Availible Entry";
            // 
            // txtTotalTicketsIssued
            // 
            this.txtTotalTicketsIssued.Location = new System.Drawing.Point(121, 45);
            this.txtTotalTicketsIssued.Name = "txtTotalTicketsIssued";
            this.txtTotalTicketsIssued.ReadOnly = true;
            this.txtTotalTicketsIssued.Size = new System.Drawing.Size(127, 20);
            this.txtTotalTicketsIssued.TabIndex = 3;
            this.txtTotalTicketsIssued.TabStop = false;
            // 
            // txtNextAvailibleEntry
            // 
            this.txtNextAvailibleEntry.Location = new System.Drawing.Point(121, 77);
            this.txtNextAvailibleEntry.Name = "txtNextAvailibleEntry";
            this.txtNextAvailibleEntry.ReadOnly = true;
            this.txtNextAvailibleEntry.Size = new System.Drawing.Size(127, 20);
            this.txtNextAvailibleEntry.TabIndex = 4;
            this.txtNextAvailibleEntry.TabStop = false;
            // 
            // btnIssueTicket
            // 
            this.btnIssueTicket.Location = new System.Drawing.Point(18, 119);
            this.btnIssueTicket.Name = "btnIssueTicket";
            this.btnIssueTicket.Size = new System.Drawing.Size(75, 23);
            this.btnIssueTicket.TabIndex = 5;
            this.btnIssueTicket.Text = "Issue Ticket";
            this.btnIssueTicket.UseVisualStyleBackColor = true;
            this.btnIssueTicket.Click += new System.EventHandler(this.btnIssueTicket_Click);
            // 
            // btnOptions
            // 
            this.btnOptions.Location = new System.Drawing.Point(38, 249);
            this.btnOptions.Name = "btnOptions";
            this.btnOptions.Size = new System.Drawing.Size(75, 23);
            this.btnOptions.TabIndex = 7;
            this.btnOptions.Text = "Options";
            this.btnOptions.UseVisualStyleBackColor = true;
            this.btnOptions.Click += new System.EventHandler(this.btnOptions_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(212, 249);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 23);
            this.btnExit.TabIndex = 8;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // lstTickets
            // 
            this.lstTickets.FormattingEnabled = true;
            this.lstTickets.Location = new System.Drawing.Point(18, 167);
            this.lstTickets.Name = "lstTickets";
            this.lstTickets.Size = new System.Drawing.Size(291, 69);
            this.lstTickets.TabIndex = 9;
            this.lstTickets.SelectedIndexChanged += new System.EventHandler(this.lstTickets_SelectedIndexChanged);
            // 
            // frmTicketIssue
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(353, 310);
            this.Controls.Add(this.lstTickets);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnOptions);
            this.Controls.Add(this.btnIssueTicket);
            this.Controls.Add(this.txtNextAvailibleEntry);
            this.Controls.Add(this.txtTotalTicketsIssued);
            this.Controls.Add(this.lblNextAvailibleEntry);
            this.Controls.Add(this.lblTotalTicketsIssued);
            this.Controls.Add(this.lblTicketAvailability);
            this.Name = "frmTicketIssue";
            this.Text = "Ticketing System Assignments";
            this.Load += new System.EventHandler(this.frmTicketIssue_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void lstTickets_SelectedIndexChanged(object sender, System.EventArgs e)
        {
            throw new System.NotImplementedException();
        }

        #endregion

        private System.Windows.Forms.Label lblTicketAvailability;
        private System.Windows.Forms.Label lblTotalTicketsIssued;
        private System.Windows.Forms.Label lblNextAvailibleEntry;
        private System.Windows.Forms.TextBox txtTotalTicketsIssued;
        private System.Windows.Forms.TextBox txtNextAvailibleEntry;
        private System.Windows.Forms.Button btnIssueTicket;
        private System.Windows.Forms.Button btnOptions;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.ListBox lstTickets;
    }
}


﻿namespace Medley_TicketIssue
{
    partial class frmOptions
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblMinutesperwindow = new System.Windows.Forms.Label();
            this.lblGuestsperwindow = new System.Windows.Forms.Label();
            this.lblStarttime = new System.Windows.Forms.Label();
            this.lblEndtime = new System.Windows.Forms.Label();
            this.lblFirstticketnumber = new System.Windows.Forms.Label();
            this.txtMinutesperwindow = new System.Windows.Forms.TextBox();
            this.txtGuestperwindow = new System.Windows.Forms.TextBox();
            this.txtStarttime = new System.Windows.Forms.TextBox();
            this.txtEndtime = new System.Windows.Forms.TextBox();
            this.txtfirstNum = new System.Windows.Forms.TextBox();
            this.btnOk = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblMinutesperwindow
            // 
            this.lblMinutesperwindow.AutoSize = true;
            this.lblMinutesperwindow.Location = new System.Drawing.Point(12, 26);
            this.lblMinutesperwindow.Name = "lblMinutesperwindow";
            this.lblMinutesperwindow.Size = new System.Drawing.Size(104, 13);
            this.lblMinutesperwindow.TabIndex = 0;
            this.lblMinutesperwindow.Text = "Minutes per window:";
            // 
            // lblGuestsperwindow
            // 
            this.lblGuestsperwindow.AutoSize = true;
            this.lblGuestsperwindow.Location = new System.Drawing.Point(12, 59);
            this.lblGuestsperwindow.Name = "lblGuestsperwindow";
            this.lblGuestsperwindow.Size = new System.Drawing.Size(100, 13);
            this.lblGuestsperwindow.TabIndex = 1;
            this.lblGuestsperwindow.Text = "Guests per window:";
            // 
            // lblStarttime
            // 
            this.lblStarttime.AutoSize = true;
            this.lblStarttime.Location = new System.Drawing.Point(12, 92);
            this.lblStarttime.Name = "lblStarttime";
            this.lblStarttime.Size = new System.Drawing.Size(54, 13);
            this.lblStarttime.TabIndex = 2;
            this.lblStarttime.Text = "Start time:";
            // 
            // lblEndtime
            // 
            this.lblEndtime.AutoSize = true;
            this.lblEndtime.Location = new System.Drawing.Point(12, 131);
            this.lblEndtime.Name = "lblEndtime";
            this.lblEndtime.Size = new System.Drawing.Size(51, 13);
            this.lblEndtime.TabIndex = 3;
            this.lblEndtime.Text = "End time:";
            // 
            // lblFirstticketnumber
            // 
            this.lblFirstticketnumber.AutoSize = true;
            this.lblFirstticketnumber.Location = new System.Drawing.Point(12, 168);
            this.lblFirstticketnumber.Name = "lblFirstticketnumber";
            this.lblFirstticketnumber.Size = new System.Drawing.Size(96, 13);
            this.lblFirstticketnumber.TabIndex = 4;
            this.lblFirstticketnumber.Text = "First ticket number:";
            // 
            // txtMinutesperwindow
            // 
            this.txtMinutesperwindow.Location = new System.Drawing.Point(127, 19);
            this.txtMinutesperwindow.Name = "txtMinutesperwindow";
            this.txtMinutesperwindow.Size = new System.Drawing.Size(100, 20);
            this.txtMinutesperwindow.TabIndex = 5;
            // 
            // txtGuestperwindow
            // 
            this.txtGuestperwindow.Location = new System.Drawing.Point(127, 56);
            this.txtGuestperwindow.Name = "txtGuestperwindow";
            this.txtGuestperwindow.Size = new System.Drawing.Size(100, 20);
            this.txtGuestperwindow.TabIndex = 6;
            // 
            // txtStarttime
            // 
            this.txtStarttime.Location = new System.Drawing.Point(127, 89);
            this.txtStarttime.Name = "txtStarttime";
            this.txtStarttime.Size = new System.Drawing.Size(100, 20);
            this.txtStarttime.TabIndex = 7;
            // 
            // txtEndtime
            // 
            this.txtEndtime.Location = new System.Drawing.Point(127, 124);
            this.txtEndtime.Name = "txtEndtime";
            this.txtEndtime.Size = new System.Drawing.Size(100, 20);
            this.txtEndtime.TabIndex = 8;
            // 
            // txtfirstNum
            // 
            this.txtfirstNum.Location = new System.Drawing.Point(127, 161);
            this.txtfirstNum.Name = "txtfirstNum";
            this.txtfirstNum.Size = new System.Drawing.Size(100, 20);
            this.txtfirstNum.TabIndex = 9;
            // 
            // btnOk
            // 
            this.btnOk.Location = new System.Drawing.Point(94, 227);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(75, 23);
            this.btnOk.TabIndex = 10;
            this.btnOk.Text = "Ok";
            this.btnOk.UseVisualStyleBackColor = true;
            this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
            // 
            // frmOptions
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.btnOk);
            this.Controls.Add(this.txtfirstNum);
            this.Controls.Add(this.txtEndtime);
            this.Controls.Add(this.txtStarttime);
            this.Controls.Add(this.txtGuestperwindow);
            this.Controls.Add(this.txtMinutesperwindow);
            this.Controls.Add(this.lblFirstticketnumber);
            this.Controls.Add(this.lblEndtime);
            this.Controls.Add(this.lblStarttime);
            this.Controls.Add(this.lblGuestsperwindow);
            this.Controls.Add(this.lblMinutesperwindow);
            this.Name = "frmOptions";
            this.Text = "Ticketing System Options";
            this.Load += new System.EventHandler(this.frmOptions_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblMinutesperwindow;
        private System.Windows.Forms.Label lblGuestsperwindow;
        private System.Windows.Forms.Label lblStarttime;
        private System.Windows.Forms.Label lblEndtime;
        private System.Windows.Forms.Label lblFirstticketnumber;
        public System.Windows.Forms.TextBox txtMinutesperwindow;
        public System.Windows.Forms.TextBox txtGuestperwindow;
        public System.Windows.Forms.TextBox txtStarttime;
        public System.Windows.Forms.TextBox txtEndtime;
        public System.Windows.Forms.TextBox txtfirstNum;
        private System.Windows.Forms.Button btnOk;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Medley_TicketIssue
{
    public partial class frmTicketIssue : Form
    {
        public frmTicketIssue()
        {
            InitializeComponent();
        }
        private int minPerWin = 20;
        private int guestsPerWin = 20;
        private DateTime endTime;
        private DateTime startTime;
        private DateTime currentEntry;
        private int firstNum = 1;
        private int numTickets;

        private void frmTicketIssue_Load(object sender, EventArgs e)
        {
            frmOptions optionsForm = new frmOptions();

            startTime = DateTime.Now;
            endTime = startTime.AddHours(8);
            optionsForm.txtfirstNum.Text = firstNum.ToString();
            optionsForm.txtMinutesperwindow.Text = minPerWin.ToString();
            optionsForm.txtGuestperwindow.Text = guestsPerWin.ToString();
            optionsForm.txtStarttime.Text = startTime.ToShortTimeString();
            optionsForm.txtEndtime.Text = endTime.ToShortTimeString();

            if (optionsForm.ShowDialog() == DialogResult.OK)
            {
                //get values from the options form
                firstNum = Convert.ToInt32(optionsForm.txtfirstNum.Text) - 1;
                minPerWin = Convert.ToInt32(optionsForm.txtMinutesperwindow.Text);
                guestsPerWin = Convert.ToInt32(optionsForm.txtGuestperwindow.Text);
                endTime = Convert.ToDateTime(optionsForm.txtEndtime.Text);
                startTime = Convert.ToDateTime(optionsForm.txtStarttime.Text);
                
                txtNextAvailibleEntry.Text = startTime.ToString();
                txtTotalTicketsIssued.Text = firstNum.ToString();
                currentEntry = startTime;
            }
        }
        private void btnExit_Click(object sender, EventArgs e)
        {
            //Confirmed message when clicking exit
            MessageBox.Show("        Confirmed");
            Environment.Exit(0);
        }
        private void btnIssueTicket_Click(object sender, EventArgs e)
        {
            numTickets++;
            txtTotalTicketsIssued.Text = numTickets.ToString();
            lstTickets.Items.Add(numTickets.ToString() + " " + txtNextAvailibleEntry.Text);
            if (numTickets % guestsPerWin == 0)
            {
                currentEntry = currentEntry.AddMinutes(minPerWin);
                txtNextAvailibleEntry.Text = currentEntry.ToString();
            }
        }
        private void btnOptions_Click(object sender, EventArgs e)
        {
            frmOptions optionsForm = new frmOptions();
            if (optionsForm.ShowDialog() == DialogResult.OK)
            {
                //get values from the options form
                firstNum = Convert.ToInt32(optionsForm.txtfirstNum.Text) - 1;
                minPerWin = Convert.ToInt32(optionsForm.txtMinutesperwindow.Text);
                guestsPerWin = Convert.ToInt32(optionsForm.txtGuestperwindow.Text);
                endTime = Convert.ToDateTime(optionsForm.txtEndtime.Text);
                startTime = Convert.ToDateTime(optionsForm.txtStarttime.Text);

                txtNextAvailibleEntry.Text = startTime.ToString();
                txtTotalTicketsIssued.Text = firstNum.ToString();
                currentEntry = startTime;
            }
        }

    }
}
